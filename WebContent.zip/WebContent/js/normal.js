/**
 * 
 */
function turn(page) {
	window.location.href = "http:localhost:8080/page/ " + page;
}